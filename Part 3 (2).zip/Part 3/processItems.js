function ValidationForm() {
      let username = document.forms["RegForm"]["Name"];
      let email = document.forms["RegForm"]["Email"];
      let Rating = document.forms["RegForm"]["Rating"];
      let select = document.forms["RegForm"]["Subject"];
      let time = document.forms["RegForm"]["radio"];
    
     // Check if username is empty
      if(username.value == ""){ 
      	  alert("Please enter a valid Name");
        	   username.focus(); return false;
      }
      // Check if email is empty
      if(email.value == "") { 
          alert("Please enter a valid e-mail address.");
          email.focus();
          return false;
      }
      //Check if email is in the format *****@XXXXXX.XXX
      if(email.value.indexOf("@", 0) < 0) {
                  alert("The email must be in the format *****@XXXXXX.XXX .");
                  email.focus(); return false;
      }
      //Check if email is in the format *****@XXXXXX.XXX
      if(email.value.indexOf(".", 0) < 0) {
                  alert("The email must be in the format *****@XXXXXX.XXX .");
                  email.focus();  return false;
      }
         
      // Check if Rating is a number between 0 and 100
      if (isNaN(Rating.value) || Rating.value < 0 || Rating.value > 100) { 
                  alert("Please rate your coach out of 100.");
                  Rating.focus();return false;
      }
      if (Rating.value < 0) { 
        alert("Please rate your coach out of 100.");
        Rating.focus();return false;
      }
      if (Rating.value > 100) { 
        alert("Please rate your coach out of 100.");
        Rating.focus();return false;
      }

      // Check if a coach is selected
      if (select.selectedIndex < 1) { 
                  alert("Please select your coach.");
                  select.focus();return false;
      }

      // Check if training hours are selected
      if (time.value === undefined) { 
                  alert("Please select Training hours.");return false;
      }
         return true;} 
          
    