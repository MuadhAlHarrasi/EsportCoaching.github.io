function Coach(name, rating, brief, country, language) {
    this.name = name;
    this.rating = rating;
    this.brief = brief;
    this.country = country;
    this.language = language;
  }
  

  var overwatchCoaches = [
    new Coach("Ethan Summers", "5/5", "Brief about Ethan Summers", "USA", "English"),
    new Coach("Zoe Ramirez", "4.7/5", "Brief about Zoe Ramirez", "Russia", "English"),
    new Coach("Lily Nguyen", "4.9/5", "Brief about Lily Nguyen", "China", "English")
  ];
  
  var fortniteCoaches = [
    new Coach("Olivia Blackwell", "4.5/5", "Brief about Olivia Blackwell", "Canada", "English"),
    new Coach("Benjamin Cruz", "4.3/5", "Brief about Benjamin Cruz", "France", "Arabic")
  ];
  
  var cs2Coaches = [
    new Coach("Jackson Steele", "4/5", "Brief about Jackson Steele", "UK", "English"),
    new Coach("Ava Morgan", "4.2/5", "Brief about Ava Morgan", "Brazil", "English")
  ];
  
  var siegeCoaches = [
    new Coach("Lucas Chen", "4.5/5", "Brief about Lucas Chen", "Germany", "English"),
    new Coach("Mason Phillips", "4.6/5", "Brief about Mason Phillips", "Spain", "Arabic")
  ];
  